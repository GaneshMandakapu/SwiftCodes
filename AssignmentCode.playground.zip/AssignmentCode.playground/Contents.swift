import UIKit

// Create a program in swift using switch case which will have to class
var Ganesh = 10
let myLabel = UILabel(frame: CGRect(x: 0, y: 0, width:400, height: 50))

switch Ganesh{
case 0...3 : myLabel.backgroundColor = UIColor.red
case 4...7 : myLabel.backgroundColor = UIColor.green
case 8...10 : myLabel.backgroundColor = UIColor.blue
default : myLabel.backgroundColor = UIColor.gray
}

// STRING oPERATION
var string = " This is a simple string"
print("Normal String:",string)
print("Uppercased String:",string.uppercased())
print("Lowercased String:",string.lowercased())
print("Replacing String:",string.replacingOccurrences(of: string, with: "message"))


//
func add<P: Numeric>(_ x:P, _ y:P) -> P



{



    return x + y



    



}



func sub<P: Numeric>(_ x:P, _ y:P) -> P



{



    return x - y



}



func mul<P: Numeric>(_ x:P, _ y:P) -> P



{



    return x * y



}



protocol Divisible {



    static func /(lhs: Self, rhs:Self) -> Self



}



func divi<P: Divisible>(_ x:P,_ y:P) -> P



{



    return x / y



}



extension Int: Divisible {}



extension Float: Divisible {}



extension Double: Divisible {}



let x1 = 45, y1 = 5



var z = add(x1,y1)



print("\(x1) + \(y1) = \(z)")



z = sub(x1,y1)



print("\(x1) - \(y1) = \(z)")



z = mul(x1,y1)



print("\(x1) * \(y1) = \(z)")



z = divi(x1,y1)



print("\(x1) / \(y1) = \(z)")
